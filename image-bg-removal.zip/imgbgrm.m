function imgbgrm()
%% Developed by Selvakarna
% Image background removal version 0.01
% maile : electroselva@gmail.com //
% web url :www.sk-voxels.blogspot.in
% Chennai,India-42.
[a,b]=uigetfile('*');

RGB=imread(a);
RGB=imresize(RGB,[512 512]);
while true()
 
   
imshow(RGB)

h1=imfreehand(gca);


foresub = getPosition(h1);
foregroundInd = sub2ind(size(RGB),foresub(:,2),foresub(:,1));
foregroundInd=single(foregroundInd);

hold on
h2=imfreehand(gca);

backsub = getPosition(h2);
backgroundInd = sub2ind(size(RGB),backsub(:,2),backsub(:,1));
backgroundInd=single(backgroundInd);
w = waitforbuttonpress;
if w==1
    
    break
end

end

L = superpixels(RGB,500);
BW = lazysnapping(RGB,L,backgroundInd,foregroundInd);

    

maskedImage = RGB;
maskedImage(repmat(~BW,[1 1 3])) = 0;
figure; 
imshow(maskedImage)